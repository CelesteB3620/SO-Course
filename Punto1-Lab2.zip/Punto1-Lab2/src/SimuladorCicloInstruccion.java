import java.io.*;
import java.util.*;

// Clase que simula la memoria de un programa
class Memoria {
    List<String> segmentoCodigo;                 // Segmento de código (instrucciones)
    Map<String, Integer> segmentoDatos;          // Segmento de datos (variables)
    Stack<Integer> pila;                         // Segmento de pila (stack)
    int pc;                                      // Contador de programa (Program Counter)

    // Constructor que inicializa los segmentos de memoria
    public Memoria() {
        this.segmentoCodigo = new ArrayList<>();
        this.segmentoDatos = new HashMap<>();
        this.pila = new Stack<>();
        this.pc = 0; // Inicialmente el program counter está en 0
    }

    // Cargar las instrucciones en el segmento de código
    public void cargarInstrucciones(List<String> instrucciones) {
        this.segmentoCodigo = instrucciones;
    }

    // Simula la ejecución del ciclo básico de instrucciones
    public void ejecutar() {
        while (pc < segmentoCodigo.size()) {
            String instruccion = segmentoCodigo.get(pc);
            System.out.println("Ejecutando instrucción: " + instruccion);
            procesarInstruccion(instruccion);
            pc++;
        }
    }

    // Procesa cada instrucción
    public void procesarInstruccion(String instruccion) {
        String[] partes = instruccion.split(" ");
        String operacion = partes[0];

        switch (operacion) {
            case "LOAD":
                // Cargar un valor en la memoria de datos
                String variable = partes[1];
                int valor = Integer.parseInt(partes[2]);
                segmentoDatos.put(variable, valor);
                System.out.println("LOAD: Guardando " + valor + " en " + variable);
                break;

            case "ADD":
                // Sumar dos variables y guardar el resultado
                String var1 = partes[1];
                String var2 = partes[2];
                int resultado = segmentoDatos.getOrDefault(var1, 0) + segmentoDatos.getOrDefault(var2, 0);
                segmentoDatos.put("RESULT", resultado);
                System.out.println("ADD: " + var1 + " + " + var2 + " = " + resultado);
                break;

            case "PUSH":
                // Empujar un valor en la pila
                String variablePush = partes[1];
                pila.push(segmentoDatos.getOrDefault(variablePush, 0));
                System.out.println("PUSH: " + variablePush + " a la pila");
                break;

            case "POP":
                // Sacar un valor de la pila
                if (!pila.isEmpty()) {
                    String variablePop = partes[1];
                    int valorPop = pila.pop();
                    segmentoDatos.put(variablePop, valorPop);
                    System.out.println("POP: " + valorPop + " de la pila a " + variablePop);
                } else {
                    System.out.println("Error: Pila vacía");
                }
                break;

            case "PRINT":
                // Imprimir el valor de una variable
                String variablePrint = partes[1];
                System.out.println("PRINT: " + variablePrint + " = "
                        + segmentoDatos.getOrDefault(variablePrint, null));
                break;

            default:
                System.out.println("Instrucción no reconocida: " + operacion);
        }
    }
}

public class SimuladorCicloInstruccion {

    // Leer las instrucciones desde un archivo de texto
    public static List<String> leerInstrucciones(String archivo) {
        List<String> instrucciones = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                instrucciones.add(linea);
            }
        } catch (IOException e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
        }
        return instrucciones;
    }

    public static void main(String[] args) {
        // Crear una instancia de la memoria
        Memoria memoria = new Memoria();

        // Leer las instrucciones desde un archivo de texto
        List<String> instrucciones = leerInstrucciones("programa.txt.rtf");

        // Cargar las instrucciones en la memoria
        memoria.cargarInstrucciones(instrucciones);

        // Ejecutar las instrucciones
        memoria.ejecutar();
    }
}

